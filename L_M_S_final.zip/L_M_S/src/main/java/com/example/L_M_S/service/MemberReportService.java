package com.example.L_M_S.service;

import com.example.L_M_S.entity.MemberReport;
import com.example.L_M_S.exception.ResourceNotFoundException;
import com.example.L_M_S.repository.MemberReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberReportService {

    @Autowired
    private MemberReportRepository memberReportRepository;

    // Create a new member report
    public MemberReport createMemberReport(MemberReport memberReport) {
        return memberReportRepository.save(memberReport);
    }

    // Get all member reports
    public List<MemberReport> getAllMemberReports() {
        return memberReportRepository.findAll();
    }

    // Get a member report by ID
    public MemberReport getMemberReportById(long id) {
        return memberReportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member report not found with id: " + id));
    }

    // Update a member report
    public MemberReport updateMemberReport(long id, MemberReport memberReportDetails) {
        MemberReport memberReport = getMemberReportById(id);

        memberReport.setIssueDate(memberReportDetails.getIssueDate());
        memberReport.setReturnDate(memberReportDetails.getReturnDate());
        memberReport.setDueDate(memberReportDetails.getDueDate());

        return memberReportRepository.save(memberReport);
    }

    // Delete a member report
    public void deleteMemberReport(long id) {
        MemberReport memberReport = getMemberReportById(id);
        memberReportRepository.delete(memberReport);
    }
}
