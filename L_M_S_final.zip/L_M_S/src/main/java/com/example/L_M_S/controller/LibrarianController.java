package com.example.L_M_S.controller;

import com.example.L_M_S.entity.Librarian;
import com.example.L_M_S.service.LibrarianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/librarians")
public class LibrarianController {

    @Autowired
    private LibrarianService librarianService;

    // Create a new librarian
    @PostMapping
    public ResponseEntity<Librarian> createLibrarian(@Valid @RequestBody Librarian librarian) {
        Librarian createdLibrarian = librarianService.createLibrarian(librarian);
        return ResponseEntity.ok(createdLibrarian);
    }

    // Get all librarians
    @GetMapping
    public ResponseEntity<List<Librarian>> getAllLibrarians() {
        List<Librarian> librarians = librarianService.getAllLibrarians();
        return ResponseEntity.ok(librarians);
    }

    // Get a librarian by ID
    @GetMapping("/{id}")
    public ResponseEntity<Librarian> getLibrarianById(@PathVariable long id) {
        Librarian librarian = librarianService.getLibrarianById(id);
        return ResponseEntity.ok(librarian);
    }

    // Update a librarian by ID
    @PutMapping("/{id}")
    public ResponseEntity<Librarian> updateLibrarian(@PathVariable long id, @Valid @RequestBody Librarian librarianDetails) {
        Librarian updatedLibrarian = librarianService.updateLibrarian(id, librarianDetails);
        return ResponseEntity.ok(updatedLibrarian);
    }

    // Delete a librarian by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLibrarian(@PathVariable long id) {
        librarianService.deleteLibrarian(id);
        return ResponseEntity.noContent().build();
    }
}
