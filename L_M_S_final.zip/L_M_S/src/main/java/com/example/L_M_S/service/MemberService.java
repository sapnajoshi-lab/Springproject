package com.example.L_M_S.service;

import com.example.L_M_S.entity.Member;
import com.example.L_M_S.exception.ResourceNotFoundException;
import com.example.L_M_S.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    // Create a new member
    public Member createMember(Member member) {
        return memberRepository.save(member);
    }

    // Get all members
    public List<Member> getAllMembers() {
        return memberRepository.findAll();
    }

    // Get a member by ID
    public Member getMemberById(long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with id: " + id));
    }

    // Update a member
    public Member updateMember(long id, Member memberDetails) {
        Member member = getMemberById(id);

        member.setName(memberDetails.getName());
        member.setEmail(memberDetails.getEmail());
        member.setPassword(memberDetails.getPassword());
        member.setPhoneNo(memberDetails.getPhoneNo());

        return memberRepository.save(member);
    }

    // Delete a member
    public void deleteMember(long id) {
        Member member = getMemberById(id);
        memberRepository.delete(member);
    }
}