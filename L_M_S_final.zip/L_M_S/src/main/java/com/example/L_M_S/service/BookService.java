package com.example.L_M_S.service;

import com.example.L_M_S.entity.Book;
import com.example.L_M_S.exception.ResourceNotFoundException;
import com.example.L_M_S.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    // Create a new book
    public Book createBook(Book book) {
        return bookRepository.save(book);
    }

    // Get all books
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // Get a book by ID
    public Book getBookById(long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
    }

    // Update a book
    public Book updateBook(long id, Book bookDetails) {
        Book book = getBookById(id);

        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setYearOfPublication(bookDetails.getYearOfPublication());

        return bookRepository.save(book);
    }

    // Delete a book
    public void deleteBook(long id) {
        Book book = getBookById(id);
        bookRepository.delete(book);
    }
}
