package com.example.L_M_S.entity;

import java.sql.Date;

import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="member_Reports")

public class MemberReport {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @NotNull(message = "Issue date cannot be null")
    @PastOrPresent(message = "Issue date cannot be in the future")
    @Column(name = "issue_date")
    private Date issueDate;

    @PastOrPresent(message = "Return date cannot be in the future")
    @Column(name = "return_date")
    private Date returnDate;

    @NotNull(message = "Due date cannot be null")
    @FutureOrPresent(message = "Due date must be today or in the future")
    @Column(name = "due_date")
    private Date dueDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public MemberReport(long id,
			@NotNull(message = "Issue date cannot be null") @PastOrPresent(message = "Issue date cannot be in the future") Date issueDate,
			@PastOrPresent(message = "Return date cannot be in the future") Date returnDate,
			@NotNull(message = "Due date cannot be null") @FutureOrPresent(message = "Due date must be today or in the future") Date dueDate) {
		super();
		this.id = id;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.dueDate = dueDate;
	}

	public MemberReport() {
		super();
	}

	@Override
	public String toString() {
		return "MemberReport [id=" + id + ", issueDate=" + issueDate + ", returnDate=" + returnDate + ", dueDate="
				+ dueDate + "]";
	}

	
}
