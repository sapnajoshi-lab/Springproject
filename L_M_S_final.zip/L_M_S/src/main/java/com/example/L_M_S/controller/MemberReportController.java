package com.example.L_M_S.controller;

import com.example.L_M_S.entity.MemberReport;
import com.example.L_M_S.service.MemberReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/member-reports")
public class MemberReportController {

    @Autowired
    private MemberReportService memberReportService;

    // Create a new member report
    @PostMapping
    public ResponseEntity<MemberReport> createMemberReport(@Valid @RequestBody MemberReport memberReport) {
        MemberReport createdReport = memberReportService.createMemberReport(memberReport);
        return ResponseEntity.ok(createdReport);
    }

    // Get all member reports
    @GetMapping
    public ResponseEntity<List<MemberReport>> getAllMemberReports() {
        List<MemberReport> reports = memberReportService.getAllMemberReports();
        return ResponseEntity.ok(reports);
    }

    // Get a member report by ID
    @GetMapping("/{id}")
    public ResponseEntity<MemberReport> getMemberReportById(@PathVariable long id) {
        MemberReport report = memberReportService.getMemberReportById(id);
        return ResponseEntity.ok(report);
    }

    // Update a member report by ID
    @PutMapping("/{id}")
    public ResponseEntity<MemberReport> updateMemberReport(@PathVariable long id, @Valid @RequestBody MemberReport reportDetails) {
        MemberReport updatedReport = memberReportService.updateMemberReport(id, reportDetails);
        return ResponseEntity.ok(updatedReport);
    }

    // Delete a member report by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMemberReport(@PathVariable long id) {
        memberReportService.deleteMemberReport(id);
        return ResponseEntity.noContent().build();
    }
}
