package com.example.L_M_S.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.L_M_S.entity.Librarian;


@Repository
public interface LibrarianRepository extends JpaRepository<Librarian, Long>{

}