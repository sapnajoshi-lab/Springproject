package com.example.L_M_S.entity;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="member")

public class Member {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "member_id")
    private Long id;

    @Column(length = 20, nullable = false)
    @NotNull(message = "Name is required")
    @Size(min = 2, max = 20)
    private String name;

    @Column(length = 30, nullable = false, unique = true)
    @NotNull(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    @Column(length = 10, nullable = false)
    @NotNull(message = "Password is required")
    private String password;
    
    @Column(length = 30, nullable = false, unique = true)
    @NotNull(message = "Phone number is required")
    @Pattern(regexp = "[6789]{1}[0-9]{9}", message = "Enter a proper phone number")
    private String phoneNo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Member(Long id, @NotNull(message = "Name is required") @Size(min = 2, max = 20) String name,
			@NotNull(message = "Email is required") @Email(message = "Email should be valid") String email,
			@NotNull(message = "Password is required") String password,
			@NotNull(message = "Phone number is required") @Pattern(regexp = "[6789]{1}[0-9]{9}", message = "Enter a proper phone number") String phoneNo) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.phoneNo = phoneNo;
	}

	public Member() {
		super();
	}

	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", phoneNo="
				+ phoneNo + "]";
	}
    
    
}
