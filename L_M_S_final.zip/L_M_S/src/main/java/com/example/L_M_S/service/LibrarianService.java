package com.example.L_M_S.service;

import com.example.L_M_S.entity.Librarian;
import com.example.L_M_S.exception.ResourceNotFoundException;
import com.example.L_M_S.repository.LibrarianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LibrarianService {

    @Autowired
    private LibrarianRepository librarianRepository;

    // Create a new librarian
    public Librarian createLibrarian(Librarian librarian) {
        return librarianRepository.save(librarian);
    }

    // Get all librarians
    public List<Librarian> getAllLibrarians() {
        return librarianRepository.findAll();
    }

    // Get a librarian by ID
    public Librarian getLibrarianById(long id) {
        return librarianRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Librarian not found with id: " + id));
    }

    // Update a librarian
    public Librarian updateLibrarian(long id, Librarian librarianDetails) {
        Librarian librarian = getLibrarianById(id);

        librarian.setName(librarianDetails.getName());
        librarian.setEmail(librarianDetails.getEmail());
        librarian.setPassword(librarianDetails.getPassword());

        return librarianRepository.save(librarian);
    }

    // Delete a librarian
    public void deleteLibrarian(long id) {
        Librarian librarian = getLibrarianById(id);
        librarianRepository.delete(librarian);
    }
}
