package com.example.L_M_S.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="bookinfo")

public class Book {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotNull(message = "Title cannot be null")
    @Size(min = 3, max = 100, message = "Title should be between 3 and 100 characters")
    private String title;

    @NotNull(message = "Author cannot be null")
    @Size(min = 3, max = 50, message = "Author name should be between 3 and 50 characters")
    private String author;

    @NotNull(message = "Year of publication cannot be null")
    @Min(value = 1000, message = "Year of publication must be greater than or equal to 1000")
    @Max(value = 2025, message = "Year of publication cannot be in the future")
    private int yearOfPublication;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getYearOfPublication() {
		return yearOfPublication;
	}

	public void setYearOfPublication(int yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}

	public Book(long id,
			@NotNull(message = "Title cannot be null") @Size(min = 3, max = 100, message = "Title should be between 3 and 100 characters") String title,
			@NotNull(message = "Author cannot be null") @Size(min = 3, max = 50, message = "Author name should be between 3 and 50 characters") String author,
			@NotNull(message = "Year of publication cannot be null") @Min(value = 1000, message = "Year of publication must be greater than or equal to 1000") @Max(value = 2025, message = "Year of publication cannot be in the future") int yearOfPublication) {
		super();
		this.id = id;
		this.title = title;
		this.author = author;
		this.yearOfPublication = yearOfPublication;
	}

	public Book() {
		super();
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", author=" + author + ", yearOfPublication=" + yearOfPublication
				+ "]";
	}
    
    
}
